BUILD THE APK (no installs needed)
1. Create a free account at github.com and make a new repository.
2. Upload ALL files/folders from this project (keep the .github folder, www folder).
3. Open the "Actions" tab -> "Build APK" -> wait ~5 minutes for the green tick.
4. Open that run -> Artifacts -> download "AC-Technician-APK" (zip) -> extract app-debug.apk.
5. Copy to your phone and install (allow "Install unknown apps").
